package tqs.ua.tqs01proj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tqs01projApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tqs01projApplication.class, args);
	}

}
