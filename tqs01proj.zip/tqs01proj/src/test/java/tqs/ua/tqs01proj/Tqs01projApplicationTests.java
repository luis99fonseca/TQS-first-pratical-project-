package tqs.ua.tqs01proj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tqs01projApplicationTests {

	@Test
	void contextLoads() {
	}

}
